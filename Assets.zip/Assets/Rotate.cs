using UnityEngine;

public class Rotate : MonoBehaviour
{
    public float speed = 5f;     // Rotation speed

    public AudioClip pickupSound;
    public int scoreValue = 10;  // Points for collecting this pickup

    


    void Update()
    {
        // Rotate the object around the Y axis
        transform.Rotate(new Vector3(0, 10, 0) * Time.deltaTime * speed);
    }

    void OnTriggerEnter(Collider other)
    {
        // Check if the object that touched this has the "Player" tag
        if (other.CompareTag("Player"))
        {

            // Add points to the player's score
            if (GameManager.instance != null)
            {
                GameManager.instance.AddScore(scoreValue);
            }

            if (pickupSound != null)
            {
                AudioSource.PlayClipAtPoint(pickupSound, transform.position, 1f);
            }

            

            // Make the pickup disappear
            gameObject.SetActive(false);
        }
    }

    
}
