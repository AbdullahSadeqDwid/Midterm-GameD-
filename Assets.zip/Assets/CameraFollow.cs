using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    public Transform player;   // Player to follow
    public Vector3 offset = new Vector3(0f, 5f, -7f); // Camera distance
    public float smoothSpeed = 5f; // Smooth movement speed

    void LateUpdate()
    {
        if (player != null)
        {
            // Calculate desired position
            Vector3 desiredPosition = player.position + offset;

            // Smoothly move camera toward that position
            Vector3 smoothedPosition = Vector3.Lerp(transform.position, desiredPosition, smoothSpeed * Time.deltaTime);

            // Apply new position
            transform.position = smoothedPosition;

            // Keep camera looking at the player
            transform.LookAt(player);
        }
    }
}
