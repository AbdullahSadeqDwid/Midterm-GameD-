using UnityEngine;
using UnityEngine.AI;

public class EnemyMovement : MonoBehaviour
{
    public Transform playerTransform;
    private NavMeshAgent navMeshAgent;

    public AudioClip GameOver;
    public GameObject GameOverPanel;


    void Start()
    {
        navMeshAgent = GetComponent<NavMeshAgent>();
    }

    void Update()
    {
        if (playerTransform != null)
        {
            navMeshAgent.SetDestination(playerTransform.position);
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            Debug.Log("Enemy caught the player!");

            if (GameOver != null)
            {
                AudioSource.PlayClipAtPoint(GameOver, Camera.main.transform.position, 1f);
            }

            if (GameOverPanel != null)
            {
                GameOverPanel.SetActive(true);
            }


            if (GameManager.instance != null)
            {
                GameManager.instance.GameOver(); // 🚨 End the game
            }
        }
    }
}
