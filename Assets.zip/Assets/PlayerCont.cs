using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerCont : MonoBehaviour
{
     public float speed = 10;      // Movement speed
    private Rigidbody rb;         // Reference to Rigidbody

    void Start()
    {
        // Get the Rigidbody component attached to the player
        rb = GetComponent<Rigidbody>();
    }

    void FixedUpdate()
    {
        // Get input from keyboard
        float moveX = Input.GetAxis("Horizontal");
        float moveZ = Input.GetAxis("Vertical");

        // Create movement direction
        Vector3 movement = new Vector3(moveX, 0, moveZ);

        // Move the player smoothly
        rb.MovePosition(rb.position + movement * speed * Time.fixedDeltaTime);
}
}

