using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public static GameManager instance;

    public int score = 0;
    public Text scoreText;
    public GameObject gameOverPanel; // UI panel to show on Game Over
    public Text TimerText;

    public float TimeRemaining = 60f; 
    private bool isGameOver = false;



    void Awake()
    {
        instance = this;
    }
    
    void Update()
    {
        if (!isGameOver)
        {
            // Decrease time each frame
            TimeRemaining -= Time.deltaTime;

            // Update timer text on screen
            if (TimerText != null)
            {
                TimerText.text = "Time: " + Mathf.CeilToInt(TimeRemaining).ToString();
            }

            // When time hits 0, end the game
            if (TimeRemaining <= 0)
            {
                TimeRemaining = 0;
                GameOver();
            }
        }
    }

    public void AddScore(int amount)
    {
        score += amount;
        if (scoreText != null)
            scoreText.text = "Score: " + score;
    }

    public void GameOver()
    {
        Debug.Log("GAME OVER!");
        Time.timeScale = 0f; // stop all movement and timers

        if (gameOverPanel != null)
            gameOverPanel.SetActive(true); // show Game Over screen
    }

    public void RestartGame()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
}
